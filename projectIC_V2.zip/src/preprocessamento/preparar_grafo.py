import pandas as pd
import numpy as np
import torch
import os
from scipy.spatial.distance import cdist

def haversine_np(lon1, lat1, lon2, lat2):
    """Cálculo de Distância Haversine otimizado para arrays NumPy."""
    lon1, lat1, lon2, lat2 = map(np.radians, [lon1, lat1, lon2, lat2])
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = np.sin(dlat/2.0)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2.0)**2
    c = 2 * np.arcsin(np.sqrt(a))
    return 6371 * c  # Retorno em km

def gerar_grafo_stgcn(threshold_km=1.5):
    # Configuração de caminhos baseada na estrutura do seu projeto
    base_dir = r'C:\IC\Projeto_V2'
    input_path = os.path.join(base_dir, 'data', 'tratados', 'dataset_PosFeaturesEngineered.csv')
    output_dir = os.path.join(base_dir, 'data', 'tratados')

    print(f"Carregando dados preparados de: {input_path}")
    df = pd.read_csv(input_path)
    
    # 1. Extração das Coordenadas para o Grafo 
    # Usaremos Latitude e Longitude para definir quem é vizinho de quem
    coords = df[['Longitude', 'Latitude']].values
    num_nodes = len(coords)

    # 2. Construção da Matriz de Adjacência Esparsa (edge_index) 
    print(f"Calculando conexões geográficas (Raio: {threshold_km}km)...")
    dist_matrix = cdist(coords, coords, lambda u, v: haversine_np(u[0], u[1], v[0], v[1]))
    
    # Encontra conexões dentro do raio, excluindo self-loops (dist > 0)
    rows, cols = np.where((dist_matrix <= threshold_km) & (dist_matrix > 0))
    edge_index = torch.tensor(np.array([rows, cols]), dtype=torch.long)
    
    # Pesos das arestas (Inverso da distância para dar mais importância aos vizinhos próximos)
    distances = dist_matrix[rows, cols]
    edge_attr = torch.tensor(1.0 / (distances + 1e-5), dtype=torch.float)

    # 3. Preparação das Features de Nó (X) 
    # Removemos colunas espaciais que não são features de treinamento
    x_columns = [col for col in df.columns if col not in ['Latitude', 'Longitude']]
    x_tensor = torch.tensor(df[x_columns].values, dtype=torch.float)

    # 4. Salvamento dos Tensores para o PyTorch Geometric
    torch.save(edge_index, os.path.join(output_dir, 'edge_index.pt'))
    torch.save(edge_attr, os.path.join(output_dir, 'edge_attr.pt'))
    torch.save(x_tensor, os.path.join(output_dir, 'x_features.pt'))

    print("-" * 40)
    print("✅ PROCESSAMENTO DO GRAFO CONCLUÍDO")
    print(f"Número de Nós (Sensores): {num_nodes}")
    print(f"Número de Arestas (Conexões): {edge_index.shape[1]}")
    print(f"Total de Features por Nó: {len(x_columns)}")
    print(f"Arquivos salvos em: {output_dir}")
    print("-" * 40)

if __name__ == "__main__":
    gerar_grafo_stgcn()